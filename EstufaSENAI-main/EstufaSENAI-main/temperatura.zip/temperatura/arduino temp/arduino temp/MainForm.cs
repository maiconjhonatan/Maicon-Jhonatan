﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;

namespace arduino_temp
{
	
	public partial class MainForm : Form
	{
		private SerialPort portaSerial;
        private string dadosRecebidos = "";
        private delegate void ProcessarDadosDelegado(string dados);
        
       
		
		
		
		public MainForm()
		{
			
			InitializeComponent();
			ConfigurarPortaSerial();
        }
			private void ConfigurarPortaSerial()
        {
            portaSerial = new SerialPort();
            portaSerial.PortName = "COM3";
            portaSerial.BaudRate = 9600;

            portaSerial.DataReceived += new SerialDataReceivedEventHandler(PortaSerial_DataReceived);

            try
            {
                portaSerial.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar à porta serial: " + ex.Message, "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PortaSerial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                dadosRecebidos = portaSerial.ReadLine();
                this.BeginInvoke(new ProcessarDadosDelegado(AtualizarInterface), dadosRecebidos);
            }
            catch
            {
            }
        }

        private void AtualizarInterface(string linhaDados)
        {
            try
            {
                string[] valores = linhaDados.Trim().Split(',');

                if (valores.Length >= 2)
                {
                    string tempStr = valores[0];
                    string umidStr = valores[1];

                    lblTemperatura.Text = "TEMPERATURA: " + tempStr + " °C";
                    lblUmidade.Text = "UMIDADE: " + umidStr + " %";

                    string horaAtual = DateTime.Now.ToString("HH:mm:ss");
                    dataGridView1.Rows.Add(tempStr + " °C", umidStr + " %", horaAtual);
                }
            }
            catch
            {
            }
        }

        private void DataGridView1CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count - 1)
            {
                DataGridViewRow linha = dataGridView1.Rows[e.RowIndex];

                if (linha.Cells[0].Value != null)
                    lblTemperatura.Text = "TEMPERATURA: " + linha.Cells[0].Value.ToString();

                if (linha.Cells[1].Value != null)
                    lblUmidade.Text = "UMIDADE: " + linha.Cells[1].Value.ToString();
            }
        }

        private void Button1Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Cells[0].Value != null)
            {
                string valorStr = dataGridView1.CurrentRow.Cells[0].Value.ToString().Replace(" °C", "");
                double temp;

                if (double.TryParse(valorStr, out temp))
                {
                    if (temp > 30)
                        MessageBox.Show("Temperatura Crítica (" + temp + " °C)! Acima do ideal.", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else if (temp < 15)
                        MessageBox.Show("Temperatura Baixa (" + temp + " °C)! Abaixo do ideal.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Temperatura Ideal (" + temp + " °C).", "Status Normal", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Selecione uma linha válida na tabela para analisar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Button2Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Cells[1].Value != null)
            {
                string valorStr = dataGridView1.CurrentRow.Cells[1].Value.ToString().Replace(" %", "");
                double umid;

                if (double.TryParse(valorStr, out umid))
                {
                    if (umid < 30)
                        MessageBox.Show("Umidade Baixa (" + umid + " %)! Ar muito seco.", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else if (umid > 70)
                        MessageBox.Show("Umidade Elevada (" + umid + " %).", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Umidade Ideal (" + umid + " %).", "Status Normal", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Selecione uma linha válida na tabela para analisar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SalvarEmCSV()
        {
            try
            {
                string caminhoArquivo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Historico_Estufa.csv");

                using (StreamWriter writer = new StreamWriter(caminhoArquivo, false))
                {
                    writer.WriteLine("Temperatura,Umidade,Hora");

                    foreach (DataGridViewRow linha in dataGridView1.Rows)
                    {
                        if (!linha.IsNewRow)
                        {
                            string temp = linha.Cells[0].Value != null ? linha.Cells[0].Value.ToString() : "";
                            string umid = linha.Cells[1].Value != null ? linha.Cells[1].Value.ToString() : "";
                            string hora = linha.Cells[2].Value != null ? linha.Cells[2].Value.ToString() : "";

                            writer.WriteLine(temp + "," + umid + "," + hora);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SalvarEmCSV();

            if (portaSerial != null && portaSerial.IsOpen)
            {
                portaSerial.Close();
            }
        }
    }
}
			
		
	

