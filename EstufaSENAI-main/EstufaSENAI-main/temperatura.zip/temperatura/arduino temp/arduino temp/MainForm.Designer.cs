﻿/*
 * Created by SharpDevelop.
 * User: Admin
 * Date: 19/08/2026
 * Time: 14:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace arduino_temp
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label lblTemperatura;
		private System.Windows.Forms.Label lblUmidade;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn colTemperatura;
		private System.Windows.Forms.DataGridViewTextBoxColumn cloUmidade;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.lblUmidade = new System.Windows.Forms.Label();
			this.lblTemperatura = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.colTemperatura = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.cloUmidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.lblUmidade);
			this.groupBox1.Controls.Add(this.lblTemperatura);
			this.groupBox1.Location = new System.Drawing.Point(12, 32);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(387, 193);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			// 
			// lblUmidade
			// 
			this.lblUmidade.Location = new System.Drawing.Point(7, 118);
			this.lblUmidade.Name = "lblUmidade";
			this.lblUmidade.Size = new System.Drawing.Size(266, 55);
			this.lblUmidade.TabIndex = 1;
			this.lblUmidade.Text = "Umidade";
			// 
			// lblTemperatura
			// 
			this.lblTemperatura.Location = new System.Drawing.Point(7, 49);
			this.lblTemperatura.Name = "lblTemperatura";
			this.lblTemperatura.Size = new System.Drawing.Size(266, 55);
			this.lblTemperatura.TabIndex = 0;
			this.lblTemperatura.Text = "Temperatura";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.dataGridView1);
			this.groupBox2.Location = new System.Drawing.Point(12, 257);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(566, 340);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
			this.colTemperatura,
			this.cloUmidade});
			this.dataGridView1.Location = new System.Drawing.Point(78, 47);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(423, 240);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1CellContentClick);
			// 
			// colTemperatura
			// 
			this.colTemperatura.HeaderText = "TEMPERATURA";
			this.colTemperatura.Name = "colTemperatura";
			this.colTemperatura.Width = 190;
			// 
			// cloUmidade
			// 
			this.cloUmidade.HeaderText = "UMIDADE";
			this.cloUmidade.Name = "cloUmidade";
			this.cloUmidade.Width = 190;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(584, 268);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(315, 89);
			this.button1.TabIndex = 2;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(584, 398);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(315, 89);
			this.button2.TabIndex = 3;
			this.button2.Text = "button2";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1803, 1061);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
			this.Name = "MainForm";
			this.Text = "arduino temp";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);

		}
	}
}
